function goTo(page) {
    alert("Navigating to: " + page.toUpperCase());
}
